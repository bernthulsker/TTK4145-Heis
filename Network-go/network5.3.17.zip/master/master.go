package master

import (
	//."../definitions"
	"fmt"
)



func MasterLoop(amIMaster chan bool){
	fmt.Println("MasterLoop")
	for{
		select{
		case <- amIMaster:
			//Run the masterloop
			fmt.Println("I AM MASTA")
		}
	}
}

