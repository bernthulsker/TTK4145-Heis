package udp

import (
	."../definitions"
	"./localip"
	"./bcast"
	"./peers"
	"time"
	"fmt"
	"strconv"
	//"os"
)


func UDPInit(outgoing chan Message, incoming chan Message, amIMaster chan bool, masterIDChan chan string, peerChan chan peers.PeerUpdate) (localIP string) {
	fmt.Println("UDPinit")

	localIP, err := localip.LocalIP()
	if err != nil {
		return							//FIX HVA SOM SKAL SKJE VED FEIL
	}
	localIP = "Bob"

	sendStatus(localIP)
	recieveStatus(peerChan)

	go transmitMessage(outgoing, localIP)
	go recieveMessage(incoming, localIP)
	
	return localIP	
}

func MasterInit(peerChan chan peers.PeerUpdate, amIMaster chan bool, localIP string, masterIDChan chan string, outgoing chan Message ) (masterID string){
	fmt.Println("masterInit")
	select{
	case peerInfo := <- peerChan:
		fmt.Printf("Peer update:\n")
		fmt.Printf("  Peers:    %q\n", peerInfo.Peers)
		fmt.Printf("  New:      %q\n", peerInfo.New)
		fmt.Printf("  Lost:     %q\n", peerInfo.Lost)
		companions := peerInfo.Peers
		if (companions[0] == localIP ){
			fmt.Println("heyo")
			masterID = localIP
			amIMaster <- true
			fmt.Println(masterID)
			return masterID
		}
		for _, companion := range companions{
			fmt.Println("I am asking if "  + companion + " are a master")
			msg := Message{}
			msg.MsgType = 3
			msg.SenderID = localIP
			msg.RecieverID = companion
			outgoing <- msg
			fmt.Println("I am finished asking")
		}
		select{
		case masterID = <-masterIDChan:
			fmt.Println("masterInitFinished")
				return masterID
		}
	}
}

func UDPUpkeep(peerChan chan peers.PeerUpdate, amIMaster chan bool, localIP string, masterIDChan chan string, masterID string){
	for{
		select {
		case companions := <-peerChan:
			fmt.Printf("Peer update:\n")
			fmt.Printf("  Peers:    %q\n", companions.Peers)
			fmt.Printf("  New:      %q\n", companions.New)
			fmt.Printf("  Lost:     %q\n", companions.Lost)
			masterCheck(companions, amIMaster, masterID, localIP, masterIDChan)
		}
	}
}

func masterCheck(peerInfo peers.PeerUpdate, amIMaster chan bool, masterID string, localIP string, masterIDChan chan string) {
	companions := peerInfo.Peers
	for _,companion := range companions{
		if (companion < masterID){
			masterID = companion
		}
	}
	if (masterID == localIP){
		amIMaster <- true
	}
	masterIDChan <- masterID
}

func transmitMessage(outgoing chan Message, localIP string){
	transmitChan := make(chan Message)
	go bcast.Transmitter(MESSAGEPORT, transmitChan)
	for{
		select{
		case message := <- outgoing:
			fmt.Println("Broadcast message")
			message.SenderID = localIP 										//adding the localIP as senderID			
			//message.RecieverID = localIP
			transmitChan <- message 										//transmitting the mssage
			go waitForEcho(transmitChan, message)							//start new goroutine who waits for echo
		}
	}
}

func recieveMessage(incoming chan Message, localIP string){
	recieveChan := make(chan Message)
	echoChan := make(chan Message)
	go bcast.Receiver(MESSAGEPORT, recieveChan)								//starting a receiver to recieve messages
	go bcast.Transmitter(ECHOPORT, echoChan)								//starting a transmitter to transmit echo
	for{
		select{
		case  message := <- recieveChan:
			fmt.Println("Recieved " + strconv.Itoa(message.MsgType))
			if(message.RecieverID == localIP){								//checking to see if the message was ment for you
				fmt.Println("Echoing")
				echoChan <- message 										// putting out an echo on the echoport								
				incoming <- message 										//transmitting the message back to main and further

			}
		}
	}
}

func waitForEcho(transmitChan chan Message, message Message, ){
	ticker := time.NewTicker(time.Millisecond * 1000).C 					//waiting one second between resends
	echoChan := make(chan Message)
	doneChan := make(chan bool)
	i := 0
	go bcast.Receiver(ECHOPORT, echoChan)
	for{
		select{
		case <- ticker:
			fmt.Println("Rebroadcast")
			transmitChan <- message 										//rebroadcasting if there is no reply
			i+=1
			if(i > 5){
				doneChan <- true											//if no reply in five seconds assume peer lost and stop the  goroutine
				//HER MÅ OGSÅ MELDINGENE SENDES TILBAKE SÅ DE KAN BEHANDLS PÅ NYTT OG SENDES TIL NY RIKTIG PEER
			}
		case echo := <-echoChan:
			fmt.Println("Recieved echo")
			if(echo == message){ 											//checking to see if you recieved the right echo
				fmt.Println("Recieved right echo")
				doneChan <- true 											
			}
		case <- doneChan:
			fmt.Println("Stopping ticker")
			return															//when the right echo were recieved, stop the echo
		}
	}
}

func sendStatus(localIP string){
	transmitStatus := make (chan bool)
	go peers.Transmitter(STATUSPORT, localIP, transmitStatus)
}

func recieveStatus(peerChan chan peers.PeerUpdate){
	//i need another line
	go peers.Receiver(STATUSPORT, peerChan)
}